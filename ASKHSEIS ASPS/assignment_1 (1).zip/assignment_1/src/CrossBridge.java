import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class CrossBridge {


    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> list = new ArrayList<Integer>();
        System.out.println("Kalispera kai kali bradia");
        System.out.println("dwse xronous xwrismenous, me eksodo timis 0");
        int speed = scanner.nextInt();
        while (speed > 0) {
            list.add(speed);
            speed = scanner.nextInt();
        }
        State initialState = new State();
        initialState.setStartSide(list);
        System.out.println("InitialState = " +initialState);
        SpaceSearcher spaceSearcher = new SpaceSearcher(initialState);
        State terminalState = null;
        long start = System.currentTimeMillis();
        terminalState = spaceSearcher.AStar();
        long end = System.currentTimeMillis();
        if(terminalState == null)
        {
            System.out.println("Could not find solution");
        }
        else
        {
            State temp = terminalState;
            ArrayList<State> path = new ArrayList<State>();
            path.add(terminalState);
            while(temp.getFather()!=null)
            {
                path.add(temp.getFather());
                temp = temp.getFather();
            }
            Collections.reverse(path);
            System.out.println("Finished in "+path.size()+" steps!");
            for(State item : path)
            {
                System.out.println(item.toString());
            }
        }
    }
}
