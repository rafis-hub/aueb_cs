import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class SpaceSearcher {

    private ArrayList<State> visited;
    private Queue<State> unvisited;

    public State findFasterChild(){
        State temp = unvisited.peek();

        for (State st: unvisited) {
            if (st.getScore()<temp.getScore()) temp = st;
        }
        unvisited.remove(temp);
        return temp;
    }


    public SpaceSearcher(State state){
        unvisited = new LinkedList<State>();
        visited = new ArrayList<State>();

        for (State st : state.getChildren()){
            unvisited.add(st);
        }
        visited.add(state);
    }

    public State AStar(){

        State output = null;
        while(!unvisited.isEmpty()){
//            System.out.println("exei ginei malakaia");
            State current = findFasterChild();
            for(State state : current.getChildren()){
//                System.out.println("for");
                if(!visited.contains(state) && !unvisited.contains(state)){
                    unvisited.add(state);
//                    System.out.println("if");
                }
            }
            //end Condition: If no more runners to transport.
            System.out.println(current);
            if(current.isTerminal()){
                break;
            }
            visited.add(current);
            output = current;
        }
        return output;
    }
}
