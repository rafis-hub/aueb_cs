To puzzle cross bridge prepei na ginei compile sto cmd 
kai twn triwn arxeiwn *.java kai na treksoume to 
CrossBridge to opoio dexetai ws eisodous akeraious 
arithmous xwrismenous me keno i Enter p.x.
1 2 3 4 5 0
or 
1
2
3
4
5
0
To "0" sumbolizei ton termatismo twn input.
To programma tha brei lysh kai tha thn ektypwsei 
se ena xroniko diasthma to opoio anagrafetai sto 
telos tou.
Endiktikes times eisodou einai:
1 3 6 8 12 0 