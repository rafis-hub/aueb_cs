import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        System.out.println("1. eisagwgh neou misthologikou stoixeiou" +
                "2. eisagwgh neou ergazomenou" +
                "3. eisagwgh neas kinhshs" +
                "4. emfanish twn misthologikwn stoixeiwn" +
                "5. emfanish kinhsewn ergazomenou" +
                "6. ypologismos tou plhrwteou enos ergazomenou" +
                "7. ypologismos upoxrewsewn etaireias" +
                "0. Exit");
        Scanner scanner = new Scanner(System.in);
        int input = scanner.nextInt();
        while (input != 0) {
            switch (input){
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    break;
                case 4:
                    break;
                case 5:
                    break;
                case 6:
                    break;
                case 7:
                    break;
                case 0:
                    break;
            }
            System.out.println("1. eisagwgh neou misthologikou stoixeiou" +
                    "2. eisagwgh neou ergazomenou" +
                    "3. eisagwgh neas kinhshs" +
                    "4. emfanish twn misthologikwn stoixeiwn" +
                    "5. emfanish kinhsewn ergazomenou" +
                    "6. ypologismos tou plhrwteou enos ergazomenou" +
                    "7. ypologismos upoxrewsewn etaireias" +
                    "0. Exit");
        }
    }
}
