#!/bin/bash
gcc p3180072-p3180085-p3180163-pizza1.c -o pizza1.out  -pthread
./pizza1.out 100 1000
